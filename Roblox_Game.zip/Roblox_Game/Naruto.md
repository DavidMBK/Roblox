Ecco un elenco dettagliato dei nemici dalle varie saghe di Naruto, senza includere Boruto:

### Naruto
1. **Prologo – Paese delle Onde**
   - Zabuza Momochi
   - Haku
   - Banditi di Gato

2. **Saga degli Esami di Selezione dei Chunin**
   - Orochimaru
   - Dosu Kinuta
   - Zaku Abumi
   - Kin Tsuchi
   - Gaara (inizialmente nemico)
   - Kankuro (inizialmente nemico)
   - Temari (inizialmente nemico)
   - Kabuto Yakushi (sotto copertura)

3. **Saga della Distruzione di Konoha**
   - Orochimaru
   - Kabuto Yakushi
   - Sound Four (Jirobo, Kidomaru, Sakon e Ukon, Tayuya)
   - Sand Shinobi (inizialmente)

4. **Saga della Ricerca di Tsunade**
   - Orochimaru
   - Kabuto Yakushi

5. **Saga del Recupero di Sasuke**
   - Sound Four (Jirobo, Kidomaru, Sakon e Ukon, Tayuya)
   - Kimimaro
   - Sasuke Uchiha (inizialmente)

### Naruto Shippuden
1. **Saga del Salvataggio del Kazekage**
   - Akatsuki (Deidara, Sasori)
   - Yura (sotto copertura)
   - Mukade (solo nell'anime)

2. **Saga del Doppio Tradimento**
   - Akatsuki (Hidan, Kakuzu)
   - Team Asuma (Hidan, Kakuzu, Team Ino-Shika-Cho)

3. **Saga di Itachi**
   - Akatsuki (Itachi Uchiha, Kisame Hoshigaki)
   - Tobi (in incognito)

4. **Saga dell'Eremita dei Sei Sentieri**
   - Pain (Nagato)
   - Konan

5. **Saga del Summit dei Kage**
   - Akatsuki (Sasuke Uchiha, Suigetsu Hozuki, Karin, Jugo)
   - Zetsu

6. **Saga della Quarta Guerra Mondiale dei Ninja**
   - Akatsuki (Kabuto Yakushi, Tobi/Obito Uchiha, Madara Uchiha, Zetsu)
   - Edo Tensei (vari ninja rianimati)
   - Jinchuriki rianimati

7. **Saga della Fine**
   - Kaguya Otsutsuki
   - Black Zetsu
   - Madara Uchiha (nelle fasi finali)
   - Obito Uchiha (nelle fasi finali)

### Nemici Ricorrenti
1. **Akatsuki**
   - Pain/Nagato
   - Konan
   - Itachi Uchiha
   - Kisame Hoshigaki
   - Deidara
   - Sasori
   - Hidan
   - Kakuzu
   - Tobi/Obito Uchiha
   - Zetsu
   - Orochimaru (inizialmente)

2. **Orochimaru e i suoi Seguaci**
   - Kabuto Yakushi
   - Sound Four
   - Kimimaro

3. **Altri Antagonisti Minori**
   - Mizuki
   - Gato
   - Hidan
   - Kakuzu
   - Amachi (solo anime)
   - Furido (Kazuma, solo anime)
   - Guren (solo anime)
   - Raiga Kurosuki (solo anime)
   - Rokusuke (solo anime)
   - Hiruko (solo film)

Questo elenco copre la maggior parte dei nemici principali e minori presenti nelle varie saghe di Naruto fino a Naruto Shippuden. Buona fortuna con il tuo tower defense di Naruto!