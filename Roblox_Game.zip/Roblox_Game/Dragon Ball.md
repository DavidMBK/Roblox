
### Dragon Ball (Originale)
1. **Saga dell'Impero Pilaf**
   - Pilaf
   - Mai
   - Shu

2. **Saga del 21° Torneo Tenkaichi**
   - Giren
   - Bacterian
   - Ranfan
   - Namu
   - Giran

3. **Saga dell'Esercito del Fiocco Rosso**
   - Colonnello Silver
   - Colonnello White
   - Generale Blue
   - Sergente Metallic
   - Ninja Murasaki
   - Generale Copper
   - Comandante Red
   - Staff Officer Black
   - Android 8 (Hatchan, se considerato nemico inizialmente)
   - Buio il Mostro

4. **Saga di Baba la Indovina**
   - Dracula Man
   - Suke-san (Invisible Man)
   - Mummy
   - Devilman
   - Akkuman

5. **Saga del 22° Torneo Tenkaichi**
   - Tenshinhan (inizialmente)
   - Chiaotzu (inizialmente)
   - Crane Hermit

6. **Saga del Grande Demone Piccolo**
   - Tambourine
   - Cymbal
   - Drum
   - Piccolo Daimao (Grande Mago Piccolo)

7. **Saga del 23° Torneo Tenkaichi**
   - Piccolo Jr.
   - Shen (Kami posseduto)

### Dragon Ball Z
1. **Saga dei Saiyan**
   - Raditz
   - Saibamen
   - Nappa
   - Vegeta

2. **Saga di Namek e Ginew**
   - Cui
   - Dodoria
   - Zarbon
   - Guldo
   - Recoome
   - Burter
   - Jeice
   - Capitan Ginew

3. **Saga di Freezer**
   - Freezer (in tutte le sue forme)

4. **Saga degli Androidi**
   - Dr. Gero (Android 20)
   - Android 19
   - Android 17
   - Android 18
   - Android 16

5. **Saga di Cell**
   - Cell (tutte le forme)

6. **Saga di Majin Buu**
   - Spopovich
   - Yamu
   - Pui Pui
   - Yakon
   - Dabura
   - Majin Buu (tutte le forme)
   - Babidi

### Dragon Ball Super
1. **Saga di Battle of Gods**
   - Beerus (inizialmente nemico)

2. **Saga di Resurrection 'F'**
   - Sorbet
   - Tagoma
   - Shisami
   - Freezer (Golden Freezer)

3. **Saga dell'Universo 6**
   - Botamo
   - Frost
   - Magetta
   - Cabba
   - Hit

4. **Saga di Trunks del Futuro**
   - Goku Black
   - Zamasu
   - Fused Zamasu

5. **Saga del Torneo del Potere**
   - Basil
   - Lavender
   - Bergamo
   - Jiren
   - Toppo
   - Dyspo
   - Caulifla
   - Kale
   - Ribrianne
   - Anilaza

6. **Saga del Prigioniero della Pattuglia Galattica (Manga)**
   - Moro
   - Saganbo
   - Seven-Three

