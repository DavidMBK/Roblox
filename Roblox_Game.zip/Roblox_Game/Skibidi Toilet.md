### Skibidi Toilets (Skibidists)

1. **Triple Giant Skibidi Toilet**
2. **Normal Flying Toilet**
3. **Giant Flying Skibidi Toilet**
4. **G-Man Skibidi Toilet**
5. **G-Toilet 2.0**
6. **G-Toilet 3.0**
7. **G-Toilet 4.0**
8. **Skibidi Urinal**
9. **DJ Skibidi Toilet**
10. **Scientist Skibidi Toilet**
11. **Parasitic Skibidi Toilet**
12. **Large Parasitic Skibidi Toilet**
13. **Helicopter Large Parasitic Skibidi Toilet**

### Cameramen

1. **Cameraman**
2. **Normal Cameraman**
3. **Large Cameraman**
4. **Titan Cameraman**
5. **Black Cameraman**
6. **Scientist Cameraman**
7. **Engineer Cameraman**
8. **POV-Cameraman**
9. **Strider Camera**

### Speakermen

1. **Speakerman**
2. **Large Speakerman**
3. **Titan Speakerman**
4. **Scientist Speakerman**
5. **Black Speakerman**
6. **Helicopter Speaker**
7. **Strider Speaker**

### TV Men

1. **TV Man**
2. **Large TV Man**
3. **Titan TV Man**
4. **TV Woman**
5. **Scientist TV Man**

### Altri Personaggi

1. **Secret Agent**
2. **The Alliance**
3. **The Infected**